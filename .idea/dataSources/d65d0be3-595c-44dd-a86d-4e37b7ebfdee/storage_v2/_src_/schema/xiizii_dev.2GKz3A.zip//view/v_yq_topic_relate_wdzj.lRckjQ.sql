CREATE VIEW v_yq_topic_relate_wdzj AS
  SELECT
    `xiizii_dev`.`yq_topic`.`id`           AS `topicId`,
    `xiizii_dev`.`yq_topic`.`name`         AS `name`,
    `xiizii_dev`.`yq_topic`.`memo`         AS `memo`,
    `xiizii_dev`.`yq_topic_relate`.`value` AS `value`,
    `xiizii_dev`.`yq_topic_relate`.`valid` AS `valid`
  FROM (`xiizii_dev`.`yq_topic`
    LEFT JOIN `xiizii_dev`.`yq_topic_relate`
      ON ((`xiizii_dev`.`yq_topic`.`id` = `xiizii_dev`.`yq_topic_relate`.`topicId`)))
  WHERE (`xiizii_dev`.`yq_topic_relate`.`name` = 'wdzj.data');


CREATE PROCEDURE updateOrgInfo()
  BEGIN  
    -- 创建接收游标数据的变量  
    declare n varchar(255);  
    declare c varchar(65);    
    -- 创建结束标志变量  
    declare done int default false;  
    -- 创建游标  
    declare cur cursor for select nsfc_leader_all.leader_code, nsfc_organization_all.org_ChineseName from nsfc_leader_all, nsfc_organization_all, nsfc_project_all 
                           where nsfc_leader_all.leader_code = nsfc_project_all.pro_leaderCode && nsfc_organization_all.org_code = nsfc_project_all.pro_organizationCode;  
    -- 指定游标循环结束时的返回值  
    declare continue HANDLER for not found set done = true;   
    -- 打开游标  
    open cur;  
    -- 开始循环游标里的数据  
    read_loop:loop  
    -- 根据游标当前指向的一条数据  
    fetch cur into c,n;  
    -- 判断游标的循环是否结束  
    if done then  
        leave read_loop;    -- 跳出游标循环  
    end if;  
    -- 获取一条数据时，将count值进行累加操作，这里可以做任意你想做的操作，  
--     set total = total + c;  
		update nsfc_leader_all set leader_organization = n WHERE leader_code = c;
    -- 结束游标循环  
    end loop;  
    -- 关闭游标  
    close cur;  
  
    -- 输出结果  
    select c;  
END;


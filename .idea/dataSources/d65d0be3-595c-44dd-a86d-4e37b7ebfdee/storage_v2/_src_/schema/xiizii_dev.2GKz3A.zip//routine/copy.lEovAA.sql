CREATE PROCEDURE copy()
  BEGIN  
     DECLARE id varchar(64);  
     DECLARE title varchar(1500);
     DECLARE keywords varchar(1000); 
		 DECLARE abstracts text;
     DECLARE years varchar(255);
     DECLARE amount varchar(255);
     DECLARE done INT DEFAULT 0;  
     DECLARE cur1 CURSOR FOR select id , projectTitle,keywords,abstract,period,`year` from restank_cihr limit 2000;  
     DECLARE CONTINUE HANDLER FOR NOT FOUND SET done=1;  

     OPEN cur1;  
     emp_loop: LOOP  
         FETCH cur1 INTO id,title,keywords,abstracts,years,amount;  
         IF done=1 THEN  
             LEAVE emp_loop;  
         END IF;  
				 INSERT INTO `restank_test` VALUES (id,title,keywords,abstracts,years,amount);
     END LOOP emp_loop;  
     CLOSE cur1;  
END;


CREATE VIEW v_brand_tel AS
  SELECT
    `xiizii_dev`.`brand`.`id`           AS `brandId`,
    `xiizii_dev`.`brand`.`name`         AS `name`,
    `xiizii_dev`.`brand_relate`.`value` AS `value`,
    `xiizii_dev`.`brand_relate`.`valid` AS `valid`
  FROM (`xiizii_dev`.`brand`
    LEFT JOIN `xiizii_dev`.`brand_relate` ON ((`xiizii_dev`.`brand`.`id` = `xiizii_dev`.`brand_relate`.`brandId`)))
  WHERE (`xiizii_dev`.`brand_relate`.`name` = 'jd.shouhou');

